^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package katana_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.5 (2016-04-12)
------------------

1.0.4 (2016-04-11)
------------------
* Rename custom CMake target `media_files`
* Contributors: Martin Günther

1.0.3 (2015-06-29)
------------------
* fix cmake developer warning
* Contributors: Michael Görner

1.0.2 (2015-05-06)
------------------
* comment initial_joint_position in katana-gazebo urdf
  There is still no way to specify these, but gazebo5 fails
  to load the urdf because it doesn't know the tags.
* katana_description: ivcon + convex are only build dependencies
* Contributors: Martin Günther, Michael Görner

1.0.1 (2015-03-17)
------------------

1.0.0 (2015-03-16)
------------------
* Initial release to Debian packages
* Contributors: Martin Günther, Henning Deeken, Michael Görner, André Potenza
