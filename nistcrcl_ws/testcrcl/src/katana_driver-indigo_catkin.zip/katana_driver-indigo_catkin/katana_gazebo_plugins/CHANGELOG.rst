^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package katana_gazebo_plugins
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.5 (2016-04-12)
------------------
* Fix katana_gazebo_plugins compilation on Saucy
* Contributors: Martin Günther

1.0.4 (2016-04-11)
------------------
* compile gazebo plugins with c++-11
  This is required with gazebo6 and it's backwards compatible
* Contributors: Michael Görner

1.0.3 (2015-06-29)
------------------
* remove dependencies to non-existing cmake targets
* find_package gazebo instead of using PkgConfig
* Contributors: Michael Görner

1.0.2 (2015-05-06)
------------------

1.0.1 (2015-03-17)
------------------

1.0.0 (2015-03-16)
------------------
* Initial release to Debian packages
* Contributors: Martin Günther, Henning Deeken, Jochen Sprickerhof, Michael Görner, André Potenza, Karl Glatz
